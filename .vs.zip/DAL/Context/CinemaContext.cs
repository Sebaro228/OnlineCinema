using Azure.Core;
using Domain.Linking;
using Domain.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Context
{
    public class CinemaContext : IdentityDbContext<User>
    {
        public CinemaContext(DbContextOptions<CinemaContext> options) : base(options) { }

        public DbSet<Film> Films { get; set; }
        public DbSet<Trailer> Trailers { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Participant> Participants { get; set; }

        public DbSet<RefreshToken> RefreshTokens { get; set; }
        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Film>()
                .HasMany(f => f.Trailers)
                .WithOne(t => t.Film)
                .HasForeignKey(t => t.FilmId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<FilmParticipation>()
                .HasOne(fp => fp.Film)
                .WithMany(f => f.Participations)
                .HasForeignKey(fp => fp.FilmId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<FilmParticipation>()
                .HasOne(fp => fp.Participant)
                .WithMany(p => p.Participations)
                .HasForeignKey(fp => fp.ParticipantId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<FilmParticipation>()
                .HasIndex(fp => new { fp.FilmId, fp.ParticipantId, fp.ParticipantRoles })
                .IsUnique();
        }
    }
}