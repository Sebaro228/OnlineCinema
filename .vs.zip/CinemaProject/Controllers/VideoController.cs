﻿using BLL.Interfaces;
using BLL.Services;
using Domain.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CinemaProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class VideoController : ControllerBase
    {
        private static readonly Dictionary<string, string[]> AllowedVideoTypes = new()
        {
            ["video/mp4"] = [".mp4"],
            ["video/webm"] = [".webm"],
            ["video/ogg"] = [".ogg", ".ogv"],
            ["video/quicktime"] = [".mov"],
            ["video/x-msvideo"] = [".avi"],
            ["video/x-matroska"] = [".mkv"],
            ["video/mpeg"] = [".mpeg", ".mpg"],
            ["video/3gpp"] = [".3gp"]
        };

        private readonly IFilmService _service;
        public VideoController(IFilmService service)
        {
            _service = service;
        }

        [HttpPost("Create")]
        //[Authorize(Roles = "ContentManager")]
        public async Task<IActionResult> CreateVideo(string id, IFormFile video)
        {
            Film? f = await _service.GetAsync(id);
            if (f is null)
                return NotFound("A film has not been found");

            if (!string.IsNullOrEmpty(f.VideoExtension))
                return BadRequest("This film already has a video");

            if (video is null)
                return BadRequest("The video is null");
            if (video.Length <= 0)
                return BadRequest("The file size is 0");


            string mime = video.ContentType;
            string ext = Path.GetExtension(video.FileName);

            if (!AllowedVideoTypes.Values.Any(e =>
                e.Any(s => string.Equals(s, ext))))
                return BadRequest("Unallowed extension");

            if (!AllowedVideoTypes.Keys.Any(m => string.Equals(m, mime)))
                return BadRequest("Unallowed mime");

            if (!AllowedVideoTypes[mime].Any(e => string.Equals(e, ext)))
                return BadRequest("Mime does not match the specified extension of the file");

            await _service.UpdateVideoAsync(f, video.OpenReadStream(), ext, mime);
            return Created();
        }

        [HttpDelete("Delete")]
        //[Authorize(Roles = "ContentManager")]
        public async Task<IActionResult> DeleteVideo(string id)
        {
            Film? f = await _service.GetAsync(id);
            if (f is null)
                return NotFound("A film has not been found");
            if (string.IsNullOrEmpty(f.VideoExtension))
                return BadRequest("This film has no video");

            await _service.DeleteVideoAsync(f);
            return Ok();
        }

        [HttpGet("Get")]
        public async Task<IActionResult> GetVideo(string id)
        {
            Film? f = await _service.GetAsync(id);
            if (f is null)
                return NotFound("A film has not been found");

            if (string.IsNullOrEmpty(f.VideoExtension))
                return NotFound("A film has no video");
            Stream s = await _service.GetVideoAsync(f);
            return File(s, f.VideoMime);
        }

        [HttpPut("UpdateVideo")]
        //[Authorize(Roles = "ContentManager")]
        public async Task<IActionResult> UpdateVideo(string id, IFormFile video)
        {
            Film? f = await _service.GetAsync(id);
            if (f is null)
                return NotFound("A film has not been found");

            if (video is null)
                return BadRequest("The video is null");
            if (video.Length <= 0)
                return BadRequest("The file size is 0");

            string mime = video.ContentType;
            string ext = Path.GetExtension(video.FileName);

            if (!AllowedVideoTypes.Values.Any(e =>
                e.Any(s => string.Equals(s, ext))))
                return BadRequest("Unallowed extension");

            if (!AllowedVideoTypes.Keys.Any(m => string.Equals(m, mime)))
                return BadRequest("Unallowed mime");

            if (!AllowedVideoTypes[mime].Any(e => string.Equals(e, ext)))
                return BadRequest("Mime does not match the specified extension of the file");

            await _service.UpdateVideoAsync(f, video.OpenReadStream(),
                ext, mime);
            return Ok();
        }

    }
}
