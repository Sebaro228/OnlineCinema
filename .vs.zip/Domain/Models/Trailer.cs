﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class Trailer
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Title { get; set; } = string.Empty;
        public string Extension { get; set; } = string.Empty;
        public string Mime { get; set; } = string.Empty;
        public string BlobPath { get; set; } = string.Empty;
        public DateOnly Date { get; set; }
        public string FilmId { get; set; }
        [JsonIgnore]
        public Film Film { get; set; }
    }
}
