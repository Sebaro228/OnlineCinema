﻿using DAL.Interfaces;
using Domain.Models;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public class UserService : Service<User>
    {
        static UserManager<User> _userManager;
        static RoleManager<IdentityRole> _roleManager;
        public UserService(IRepository<User> rep, UserManager<User> userManager, RoleManager<IdentityRole> roleManager) : base(rep)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }
        public async Task<(bool success, string message)> AddRole(string id, string role)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return (false, "User not found");
            if (role == "User") return (false, "Cannot add User role");
            if (await _roleManager.RoleExistsAsync(role))
            {
                await _userManager.AddToRoleAsync(user, role);
                if ((await _userManager.GetRolesAsync(user)).Count > 1)
                    await _userManager.RemoveFromRoleAsync(user, "User");
                return (true, "Role added successfully");
            }
            return (false, "Role not found");
        }
        public async Task<(bool success, string message)> RemoveRole(string id, string role)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return (false, "User not found");
            if (role == "Admin" || role == "User") return (false, "Cannot remove Admin or User role");
            if (await _roleManager.RoleExistsAsync(role))
            {
                await _userManager.RemoveFromRoleAsync(user, role);
                return (true, "Role removed successfully");
            }
            return (false, "Role not found");
        }
    }
}
